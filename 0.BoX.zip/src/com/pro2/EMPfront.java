package com.pro2;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proc.EMPcommand;
import com.proc2.EdeleteCommand;
import com.proc2.EfindCommand;
import com.proc2.EinsertCommand;
import com.proc2.ElistCommand;

/**
 * Servlet implementation class EMPfront
 */
@WebServlet("*.do")
public class EMPfront extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public EMPfront() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		actionDo(request, response);
	}

	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		actionDo(request, response);
	}
	
	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("actionDo()호출");
		
		request.setCharacterEncoding("UTF-8");
		
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		
		System.out.println("uri: " + uri);  
		System.out.println("conPath: " + conPath);  
		System.out.println("com: " + com);
		
		String view = null;
		EMPcommand ecm = null;
		
		switch (com) {
		case "/EMP/Elist.do":
			ecm = new ElistCommand();
			ecm.execute(request, response);
			view = "Elist.jsp";
			break;
		case "/EMP/Einsert.do":
			ecm = new EinsertCommand();
			ecm.execute(request, response);
			view = "Einsert.jsp";
			break;
		case "/EMP/Edelete.do":
			ecm = new EdeleteCommand();
			ecm.execute(request, response);
			view = "Edelete.jsp";
			break;
		case "/EMP/Efind.do":
			ecm = new EfindCommand();
			ecm.execute(request, response);
			view = "Efind.jsp";
			break;
		
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(view);
		dispatcher.forward(request, response);
		
		
	}

}

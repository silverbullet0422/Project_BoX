package com.pro2;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.mbeans.UserMBean;

import com.proc.Ccommand;
import com.proc2.CInfoCommand;
import com.proc2.CModifyCommand;
import com.proc2.CUserBuyCommand;
import com.proc2.CDeleteCommand;
import com.proc2.CfindCommand;
import com.proc2.CinsertCommand;
import com.proc2.ClistCommand;


/**
 * Servlet implementation class EMPfront
 */
@WebServlet("*.go")
public class Cfront extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Cfront() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		actionDo(request, response);
	}

	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		actionDo(request, response);
	}
	
	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("actionDo()호출");
		
		request.setCharacterEncoding("UTF-8");
		
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		
		System.out.println("uri: " + uri);  
		System.out.println("conPath: " + conPath);  
		System.out.println("com: " + com);
		
		String view = null;
		Ccommand ccm = null;
		
		switch (com) {
		case "/CUS/Clist.go":
			ccm = new ClistCommand();
			ccm.execute(request, response);
			view = "Clist.jsp";
			break;
		case "/CUS/Cinsert.go":
			ccm = new CinsertCommand();
			ccm.execute(request, response);
			view = "Cinsert.jsp";
			break;
			
		case "/CUS/Cdelete.go":
			ccm = new CDeleteCommand();
			ccm.execute(request, response);
			view = "Cdelete.jsp";
			break;
		case "/CUS/Cfind.go":
			ccm = new CfindCommand();
			ccm.execute(request, response);
			view = "Cfind.jsp";
			break;
		case "/CUS/CInmodify.go":
			ccm = new CModifyCommand();
			ccm.execute(request, response);
			view = "CInmodify.jsp";
			break;
		case "/CLOG/CInfoForm.go":     
			ccm = new CInfoCommand();
			ccm.execute(request, response);
			view = "CInfoForm.jsp";
			break;
		case "/CLOG/CDeleteForm.go":     
			ccm = new CDeleteCommand();
			ccm.execute(request, response);
			view = "CDeleteForm.jsp";
			break;
			
		case "/CLOG/CModifyForm.go":     
			ccm = new CModifyCommand();
			ccm.execute(request, response);
			view = "CModifyForm.jsp";
			break;
		
		case "/CLOG/CUserBuyList.go":     
			ccm = new CUserBuyCommand();
			ccm.execute(request, response);
			view = "CUserBuyList.jsp";
			break;
			
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(view);
		dispatcher.forward(request, response);
		
		
	}

}

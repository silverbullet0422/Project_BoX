package com.mvc2.command;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.ex.StockDAO;
import com.test.ex.StockDTO;

public class FindCommand implements Command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		StockDAO dao = new StockDAO();
		StockDTO[] arr = null;
		
		
		try {
			arr = dao.findByName(request.getParameter("name"));
			request.setAttribute("name", arr);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
	}

}

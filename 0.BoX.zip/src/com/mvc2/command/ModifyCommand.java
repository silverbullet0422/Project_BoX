package com.mvc2.command;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.ex.StockDAO;
import com.test.ex.StockDTO;

public class ModifyCommand implements Command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		StockDAO dao = new StockDAO();
		 
		StockDTO stock = new StockDTO(
			Integer.parseInt(request.getParameter("Item_Num")),
			request.getParameter("Item_Name"), 
			request.getParameter("Item_Class"),
			Integer.parseInt(request.getParameter("Item_Volume")),
			request.getParameter("Item_Img"),
			Integer.parseInt(request.getParameter("Buy_Price")),
			Integer.parseInt(request.getParameter("Sell_Price"))
		); 
		
		int cnt = 0;
		try {
			cnt = dao.modifyById(stock);
			request.setAttribute("result", cnt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}

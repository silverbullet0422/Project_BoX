package com.mvc2.command;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.ex.StockDAO;
import com.test.ex.StockDTO;

public class ListCommand implements Command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		StockDAO dao = new StockDAO();
		StockDTO [] find = null;
		
		try {
			find = dao.select();	
			request.setAttribute("list", find); // selectの遂行結果を requestに込める
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}

package com.mvc2.frontcontroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc2.command.*;

@WebServlet("*.stock")	// どんなリクエストでも終わりが .doなら受け入れる
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FrontController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);	//1. get 方式も
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);	//2. post 方式も
	}									
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("actionDo() 호출" );	//3. 全て actionDo で整理
			
		request.setCharacterEncoding("UTF-8");
		
		// 1.URLから URIと ContextPath, Commandを 分離.
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();	// アプリケーション別事態経路
		String com = uri.substring(conPath.length());
		
		// 2. テストとして出力
		System.out.println("URI = " + uri);
		System.out.println("conPath = " + conPath);
		System.out.println("com = " + com);		// ' ~~~.do ' 
		
		// 3. コントロールはどんなCommandを遂行するか、どんな viewに forwardするかを決定
		String viewPage = null;	// (view)
		Command command = null; // どんなロジック？
		
		// 4. コントロールはコマンドによってロジックを遂行し結果を出すviewを決定
		if(com.equals("/STOCK/Slist.stock")) {
			command = new ListCommand();	
			command.execute(request, response);
			viewPage = "Slist.jsp";
			
		} else if (com.equals("/STOCK/Sinsert.stock")) {
			command = new InsertCommand();
			command.execute(request, response);
			viewPage = "Sinsert.jsp";
			
		} else if (com.equals("/Sfind.stock")) {
			command = new FindCommand();
			command.execute(request, response);
			viewPage = "Sfind.jsp";
			
		} else if (com.equals("/STOCK/Sdelete.stock")) {
			command = new DeleteCommand();
			command.execute(request, response);
			viewPage = "Sdelete.jsp";
			
		} else if (com.equals("/STOCK/Smodify.stock")) {
			command = new ModifyCommand();
			command.execute(request, response);
			viewPage = "Smodify.jsp";
			
		}
		// 5. requestを forwardする. 
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);
		
	}
	
}	// end of class

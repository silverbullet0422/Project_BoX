package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MyOracle {
	//ドライバクラスの名前
	public static final String DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
	
	//インタフェースの変数は staticメンバー
	public static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";

	public static final String USER = "scott";
	public static final String PWD = "tiger";
	
	// DB 連結メッソド
	public static Connection getConnection() throws Exception {
		Connection con;
		
		// 1. ドライバ連結
		Class.forName(DRIVER_NAME);
		// 2. DB 連結
		con = DriverManager.getConnection(URL, USER, PWD);
		return con;
	}
	
	// JDBC 資源を閉まるメッソド
	public static void closeJDBC (Connection con, PreparedStatement pstmt
			, ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	} // closeJDBC()
	
}

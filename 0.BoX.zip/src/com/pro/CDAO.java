package com.pro;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.test.ex.StockDTO;

public class CDAO {
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String uid = "scott";
	String pwd = "tiger";

	public CDAO() {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, uid, pwd);
			System.out.println("연결");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // endConstructor()

	private static CDAO instance;

	public static CDAO getInstance() {
		if (instance == null)
			instance = new CDAO();
		return instance;
	}

	public int insertCus(String Name, String Id, String Pw, String Address, String Phonenum, String Email, int Point)
			throws SQLException {

		int cnt = 0;

		try {
			String sql = "INSERT INTO CUSTOMER(User_Num, User_Name, User_Id, User_Pw,"
					+ "User_Address, User_Phonenum, User_Email, Point)"
					+ "VALUES(CUSTOMER_SEQ.nextval, ?, ?, ?, ?, ?, ?, ?)";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, Name);
			pstmt.setString(2, Id);
			pstmt.setString(3, Pw);
			pstmt.setString(4, Address);
			pstmt.setString(5, Phonenum);
			pstmt.setString(6, Email);
			pstmt.setInt(7, Point);

			cnt = pstmt.executeUpdate();

		} finally {
			if (pstmt != null)
				pstmt.close();
			// if (conn != null)
			// conn.close();
		}

		return cnt;
	} // end insertCus()

	public int insertC(CDTO cdto) throws SQLException {
		int Unum = cdto.getUnum();
		String Name = cdto.getName();
		String Id = cdto.getId();
		String Pw = cdto.getPw();
		String Address = cdto.getAddress();
		String Phonenum = cdto.getPhonenum();
		String Email = cdto.getEmail();
		int Point = cdto.getPoint();

		int cnt = this.insertCus(Name, Id, Pw, Address, Phonenum, Email, Point);
		return cnt;
	} // end insertC(CDTO)

	public CDTO[] createArray(ResultSet rs) throws SQLException {

		ArrayList<CDTO> list = new ArrayList<CDTO>();

		while (rs.next()) {
			int Unum = rs.getInt(1);
			String Name = rs.getString(2);
			String Id = rs.getString(3);
			String Pw = rs.getString(4);
			String Address = rs.getString(5);
			String Phonenum = rs.getString(6);
			String Email = rs.getString(7);
			int Point = rs.getInt(8);

			CDTO dto = new CDTO(Name, Id, Pw, Address, Phonenum, Email, Point);
			dto.setUnum(Unum);

			list.add(dto);
		} // end while

		CDTO[] arr = new CDTO[list.size()];
		list.toArray(arr);
		return arr;

	} // end createArray()

	public CDTO[] select() throws SQLException {

		try {
			String sql = "SELECT * FROM CUSTOMER ORDER BY User_Num DESC";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			return createArray(rs);
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			// if (conn != null)
			// conn.close();
		}

	} // end select
	public CDTO[] UserBuy(String id) throws SQLException{
		String sql = "select u.purchase_date, s.Item_name, u.total_price "
				+ "from user_purchase u "
				+ "join stock s on u.item_num = s.item_num "
				+ "join customer c on u.User_num = c.User_num "
				+ "where c.User_Id = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			return createArray2(rs);
			
		} finally {
			if(rs != null) rs.close();
			if(pstmt!=null) pstmt.close(); 
		}
	}	// end UserBuy
	
	public CDTO[] createArray2(ResultSet rs) throws SQLException {
		ArrayList<CDTO> list = new ArrayList<CDTO>();
		while(rs.next()) {
			String Purchase_Date = rs.getString(1);
			String Item_Name = rs.getString(2);
			int Total_Price = rs.getInt(3);
			CDTO dto = new CDTO(Purchase_Date, Item_Name, Total_Price);
			list.add(dto);
		} // end while
		CDTO[] arr = new CDTO[list.size()];
		list.toArray(arr);
		return arr;
	}


	public CDTO[] Cfind(String Id) throws SQLException {

		try {
			String sql = "SELECT * FROM CUSTOMER WHERE User_Id=? ORDER BY User_Num DESC";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, Id);
			rs = pstmt.executeQuery();

			CDTO arr[] = createArray(rs);
			return arr;

		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			// if (conn != null)
			// conn.close();
		}

	} // end find

	public int Cdelete(String Id) throws SQLException {
		try {
			String sql = "DELETE FROM CUSTOMER WHERE User_Id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, Id);
			int cnt = pstmt.executeUpdate();
			return cnt;

		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			// if (conn != null)
			// conn.close();
		}
	}

	// ログイン時のアイディとパスワードをチェックするメッソド
	// アイディとパスワードをもらう
	public int loginCheck(String id, String pw) {

		String dbPW = ""; // dbから出すパスワードを込める変数
		int x = -1;

		try {
			String sql = "SELECT User_Pw FROM CUSTOMER WHERE User_Id=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) // 入力されたアイディに当たるパスワードがある場合
			{
				dbPW = rs.getString("User_Pw"); 

				if (dbPW.equals(pw))
					x = 1; // 受け入れたパスワードと出してもらったパスワードを比べ同じ場合認証成功
				else
					x = 0; // DBのパスワードと違う場合認証失敗

			} else {
				x = -1; // 当たるアイディがなかった場合
			}

			return x;

		} catch (Exception sqle) {
			throw new RuntimeException(sqle.getMessage());
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				// if ( conn != null )conn.close();
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		} // end loginCheck()
	}

	public CDTO getUserInfo(String id) {
		/*
		 * Connection conn = null; PreparedStatement pstmt = null; ResultSet rs = null;
		 */
		CDTO customer = null;

		try {
			// クァーリー
			StringBuffer query = new StringBuffer();
			query.append("SELECT * FROM CUSTOMER WHERE User_Id=?");

			pstmt = conn.prepareStatement(query.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) // 会員情報をDTOに込める
			{
				// 자바빈에 정보를 담는다.
				customer = new CDTO();
				customer.setId(rs.getString("User_Id"));
				customer.setPw(rs.getString("User_Pw"));
				customer.setName(rs.getString("User_Name"));
				customer.setPhonenum(rs.getString("User_Phonenum"));
				customer.setAddress(rs.getString("User_Address"));
				customer.setEmail(rs.getString("User_Email"));
				customer.setPoint(rs.getInt("Point"));

				return customer;
			}
		} catch (Exception sqle) {
			throw new RuntimeException(sqle.getMessage());
		} finally {
			// Connection, PreparedStatement를 닫는다.
			try {
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				if (conn != null) {
					// conn.close();
					// conn = null;
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}

		} // end getUserInfo
		return customer;

	}

	public int deleteCustomer(String id, String pw) {

		String dbpw = ""; // DB상의 비밀번호를 담아둘 변수
		int x = -1;

		try {
			// 비밀번호 조회
			StringBuffer query1 = new StringBuffer();
			query1.append("SELECT User_Pw FROM CUSTOMER WHERE User_Id=?");

			// 회원 삭제
			StringBuffer query2 = new StringBuffer();
			query2.append("DELETE FROM CUSTOMER WHERE User_Id=?");

			// 자동 커밋을 false로 한다.
			// conn.setAutoCommit(false);

			// 1. 아이디에 해당하는 비밀번호를 조회한다.
			pstmt = conn.prepareStatement(query1.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				dbpw = rs.getString("User_Pw");
				if (dbpw.equals(pw)) // 입력된 비밀번호와 DB비번 비교
				{
					// 같을경우 회원삭제 진행
					pstmt = conn.prepareStatement(query2.toString());
					pstmt.setString(1, id);
					pstmt.executeUpdate();
					conn.commit();
					x = 1; // 삭제 성공
				} else {
					x = 0; // 비밀번호 비교결과 - 다름
				}
			}

			return x;

		} catch (Exception sqle) {
			try {
				conn.rollback(); // 오류시 롤백
			} catch (SQLException e) {
				e.printStackTrace();
			}
			throw new RuntimeException(sqle.getMessage());
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				// if ( conn != null ){ conn.close(); conn=null; }
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	} // end deleteMember

	public void updateCustomer(CDTO customer) throws SQLException {

		try {

			StringBuffer query = new StringBuffer();
			query.append("UPDATE CUSTOMER SET User_Pw =?, User_Name=? WHERE User_Id=?");
			/*
			 * query.append("User_Pw =?, User_Name=?"); query.append("WHERE User_Id=?");
			 */

			// conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(query.toString());

			// 자동 커밋을 false로 한다.
			conn.setAutoCommit(false);

			pstmt.setString(1, customer.getPw());
			pstmt.setString(2, customer.getName());
			pstmt.setString(3, customer.getId());

			pstmt.executeUpdate();
			// 완료시 커밋
			conn.commit();

		} catch (Exception sqle) {
			conn.rollback(); // 오류시 롤백
			throw new RuntimeException(sqle.getMessage());
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				// if ( conn != null ){ conn.close(); conn=null; }
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
	} // end updateMember

}

package com.pro;

public class CDTO {
	private int Unum;
	private String Name;
	private String Id;
	private String Pw;
	private String Address;
	private String Phonenum;
	private String Email;
	private int Point;
	private String Purchase_Date;
	private String Item_Name;
	private int Total_Price;
	
	public CDTO() {
		super();
		System.out.println("CDTO()생성");
	}

	public CDTO(String name, String id, String pw, String address, String phonenum, String email,
			int point) {
		super();
		System.out.println("CDTO(내용물)생성");
		
		this.Name = name;
		this.Id = id;
		this.Pw = pw;
		this.Address = address;
		this.Phonenum = phonenum;
		this.Email = email;
		this.Point = point;
	}
	
	// 오버라이드
	public CDTO(String Purchase_Date, String Item_Name, int Total_Price) {
		super();
		this.Purchase_Date = Purchase_Date;
		this.Item_Name = Item_Name;
		this.Total_Price = Total_Price;
	}
	
	/**
	 * @return the purchase_Date
	 */
	public String getPurchase_Date() {
		return Purchase_Date;
	}

	/**
	 * @param purchase_Date the purchase_Date to set
	 */
	public void setPurchase_Date(String purchase_Date) {
		Purchase_Date = purchase_Date;
	}

	/**
	 * @return the item_Name
	 */
	public String getItem_Name() {
		return Item_Name;
	}

	/**
	 * @param item_Name the item_Name to set
	 */
	public void setItem_Name(String item_Name) {
		Item_Name = item_Name;
	}

	/**
	 * @return the total_Price
	 */
	public int getTotal_Price() {
		return Total_Price;
	}

	/**
	 * @param total_Price the total_Price to set
	 */
	public void setTotal_Price(int total_Price) {
		Total_Price = total_Price;
	}

	public int getUnum() {
		return Unum;
	}

	public void setUnum(int unum) {
		this.Unum = unum;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		this.Name = name;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		this.Id = id;
	}

	public String getPw() {
		return Pw;
	}

	public void setPw(String pw) {
		this.Pw = pw;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		this.Address = address;
	}

	public String getPhonenum() {
		return Phonenum;
	}

	public void setPhonenum(String phonenum) {
		this.Phonenum = phonenum;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		this.Email = email;
	}

	public int getPoint() {
		return Point;
	}

	public void setPoint(int point) {
		this.Point = point;
	}
	
	
	
	
}

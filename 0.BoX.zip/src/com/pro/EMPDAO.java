package com.pro;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class EMPDAO {
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String uid = "scott";
	String pwd = "tiger";

	public EMPDAO() {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, uid, pwd);
			System.out.println("연결");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // endConstructor()

	public int insertEMP(String Name, String Id, String Pw, String Address, String Phonenum, String Email,
			String Position, String Dept, int Pay, String Memo) throws SQLException {
		int cnt = 0;

		try {
			String sql = "INSERT INTO EMP(Emp_Num, Emp_Name, Emp_Id, Emp_Pw, Emp_Address, Emp_Phonenum, "
					+ "Emp_Email, Emp_Position, Dept, Pay, Memo)"
					+ "VALUES(EMP_SEQ.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, Name);
			pstmt.setString(2, Id);
			pstmt.setString(3, Pw);
			pstmt.setString(4, Address);
			pstmt.setString(5, Phonenum);
			pstmt.setString(6, Email);
			pstmt.setString(7, Position);
			pstmt.setString(8, Dept);
			pstmt.setInt(9, Pay);
			pstmt.setString(10, Memo);

			cnt = pstmt.executeUpdate();

		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}

		return cnt;
	} // end insertEMP()

	public int insertEMP(EMPDTO edto) throws SQLException {
		int Enum = edto.getEnum();
		String Name = edto.getName();
		String Id = edto.getId();
		String Pw = edto.getPw();
		String Address = edto.getAddress();
		String Phonenum = edto.getPhonenum();
		String Email = edto.getEmail();
		String Position = edto.getPosition();
		String Dept = edto.getDept();
		int Pay = edto.getPay();
		String Memo = edto.getMemo();

		int cnt = this.insertEMP(Name, Id, Pw, Address, Phonenum, Email, Position, Dept, Pay, Memo);
		return cnt;
	} // end insertEMP(EMPDTO)

	public EMPDTO[] createArray(ResultSet rs) throws SQLException {

		ArrayList<EMPDTO> list = new ArrayList<EMPDTO>();

		while (rs.next()) {
			int Enum = rs.getInt(1);
			String Name = rs.getString(2);
			String Id = rs.getString(3);
			String Pw = rs.getString(4);
			String Address = rs.getString(5);
			String Phonenum = rs.getString(6);
			String Email = rs.getString(7);
			String Position = rs.getString(8);
			String Dept = rs.getString(11);
			int Pay = rs.getInt(12);
			String Memo = rs.getString(13);
			if (Memo == null)
				Memo = "입력하세요";

			EMPDTO dto = new EMPDTO(Name, Id, Pw, Address, Phonenum, Email, Position, Dept, Pay, Memo);
			dto.setEnum(Enum);

			list.add(dto);
		} // end while

		EMPDTO[] arr = new EMPDTO[list.size()];
		list.toArray(arr);
		return arr;

	} // end createArray()

	public EMPDTO[] select() throws SQLException {

		try {
			String sql = "SELECT * FROM EMP ORDER BY Emp_Num DESC";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			return createArray(rs);
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			//if (conn != null)
			//	conn.close();
		}

	}	//end select
	
	public EMPDTO[] Efind(String Id) throws SQLException{
		
		try {
			String sql = "SELECT * FROM EMP WHERE EMP_Id=? ORDER BY EMP_Num DESC";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, Id);
			rs = pstmt.executeQuery();
			
			EMPDTO arr[] = createArray(rs);
			return arr;
			
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		
	}	//end find
	
	public int Edelete(String Id) throws SQLException{
		try {
			String sql = "DELETE FROM EMP WHERE EMP_Id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, Id);
			int cnt = pstmt.executeUpdate();
			return cnt;
			
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
	}
	
	
	public int binsert(String bname, String title, String contents, String time) throws SQLException {
		
		int cnt = 0;
		try {
			
		
		String sql = "INSERT INTO EMPBOARD (Boardnum, Name, Title, Emp_contents, Regdate) "
				+ "VALUES (EMPBOARD_SEQ.nextval, ?, ?, ?, sysdate)";
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, bname);
		pstmt.setString(2, title);
		pstmt.setString(3, contents);
		
		
		cnt = pstmt.executeUpdate();
		
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		
		return cnt;
		
	}
	
	public int binsert(EMPDTO dto) throws SQLException {
		int boardnum = dto.getBoardnum();
		String bname = dto.getBname();
		String title = dto.getTitle();
		String contents = dto.getContents();
		String time = dto.getTime();
		int hit = dto.getHit();
		
		int cnt = this.binsert(bname, title, contents, time);
		return cnt;
		
		
	}
	
	public EMPDTO[] createArrayB(ResultSet rs) throws SQLException{
		ArrayList<EMPDTO> list = new ArrayList<EMPDTO>();
		
		while(rs.next()) {
			int boardnum = rs.getInt(1);
			String bname = rs.getString(2);
			String title = rs.getString(3);
			String contents = rs.getString(4);
			String time = new SimpleDateFormat("yyyy-MM-dd").format(rs.getDate(5));
			
			EMPDTO dto = new EMPDTO(bname, title, contents, time);
			dto.setBname(bname);
			list.add(dto);
			
		}
		EMPDTO[] arr = new EMPDTO[list.size()];
		list.toArray(arr);
		return arr;
	}
	
	public int eloginCheck(String id, String pw) {
        
 
        String dbPW = ""; // db에서 꺼낸 비밀번호를 담을 변수
        int x = -1;
 
        try {
            // 쿼리 - 먼저 입력된 아이디로 DB에서 비밀번호를 조회한다.
            
            String sql = "SELECT EMP_Pw FROM EMP WHERE EMP_Id=?";
 
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
 
            if (rs.next()) // 입려된 아이디에 해당하는 비번 있을경우
            {
                dbPW = rs.getString(1); // 비번을 변수에 넣는다.
 
                if (dbPW.equals(pw)) 
                    x = 1; // 넘겨받은 비번과 꺼내온 배번 비교. 같으면 인증성공
                else                  
                    x = 0; // DB의 비밀번호와 입력받은 비밀번호 다름, 인증실패
                
            } else {
                x = -1; // 해당 아이디가 없을 경우
            }
 
            return x;
 
        } catch (Exception sqle) {
            throw new RuntimeException(sqle.getMessage());
        } finally {
            try{
                if ( pstmt != null ){ pstmt.close(); pstmt=null; }
                if ( conn != null ){ conn.close(); conn=null;    }
            }catch(Exception e){
                throw new RuntimeException(e.getMessage());
            }
        }
    } // end loginCheck()
	
	public int modifyById(String Id, String Pw, String Address, String Phonenum, String Email,
			String Position, String Dept, int Pay, String Memo) throws SQLException {
	try {
		int cnt = 0;
		String sql = "update EMP set Emp_Pw = ?, Emp_Address = ?, Emp_phonenum = ?, "
				+ "Emp_Email = ?, Emp_Position = ?, Dept = ?, Pay = ?, Memo = ? where Emp_Id = ? ";
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, Pw);
		pstmt.setString(2, Address);
		pstmt.setString(3, Phonenum);
		pstmt.setString(4, Email);
		pstmt.setString(5, Position);
		pstmt.setString(6, Position);
		pstmt.setInt(7, Pay);
		pstmt.setString(8, Memo);
		pstmt.setString(9, Id);
		cnt = pstmt.executeUpdate();
		return cnt;
	} finally {
		if(rs !=null) rs.close();
		if(pstmt!=null) pstmt.close();
		if(conn !=null) conn.close();
	}
}	// end modifyById

}

package com.pro;

public class EMPDTO {
	private int Enum;
	private String Name;
	private String Id;
	private String Pw;
	private String Address;
	private String Phonenum;
	private String Email;
	private String Position;
	private String Dept;
	private int Pay;
	private String Memo;
	private int boardnum;
	private String bname;
	private String title;
	private String contents;
	private String time;
	private int hit;
	//스타트, 피니쉬 만들어야할까??
	
	
	public EMPDTO() {
		super();
		System.out.println("EMPDTO()생성");
	}
	
	
	public EMPDTO(String name, String id, String pw, String address, String phonenum, String email,
			String position, String dept, int pay, String memo) {
		super();
		System.out.println("EMPDTO(내용물)생성");
		
		this.Name = name;
		this.Id = id;
		this.Pw = pw;
		this.Address = address;
		this.Phonenum = phonenum;
		this.Email = email;
		this.Position = position;
		this.Dept = dept;
		this.Pay = pay;
		this.Memo = memo;
	}
	public EMPDTO(String id, String pw, String address, String phonenum, String email,
			String position, String dept, int pay, String memo) {
		super();
		System.out.println("EMPDTO(내용물)생성");
		
		this.Id = id;
		this.Pw = pw;
		this.Address = address;
		this.Phonenum = phonenum;
		this.Email = email;
		this.Position = position;
		this.Dept = dept;
		this.Pay = pay;
		this.Memo = memo;
	}
	
	


	public int getEnum() {
		return Enum;
	}
	public void setEnum(int enum1) {
		this.Enum = enum1;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		this.Id = id;
	}
	public String getPw() {
		return Pw;
	}
	public void setPw(String pw) {
		this.Pw = pw;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		this.Address = address;
	}
	public String getPhonenum() {
		return Phonenum;
	}
	public void setPhonenum(String phonenum) {
		this.Phonenum = phonenum;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		this.Email = email;
	}
	public String getPosition() {
		return Position;
	}
	public void setPosition(String position) {
		this.Position = position;
	}
	public String getDept() {
		return Dept;
	}
	public void setDept(String dept) {
		this.Dept = dept;
	}
	public int getPay() {
		return Pay;
	}
	public void setPay(int pay) {
		this.Pay = pay;
	}
	public String getMemo() {
		return Memo;
	}
	public void setMemo(String memo) {
		this.Memo = memo;
	}


	public EMPDTO(String bname, String title, String contents, String time) {
		super();
		
		this.bname = bname;
		this.title = title;
		this.contents = contents;
		this.time = time;
		
	}


	public int getBoardnum() {
		return boardnum;
	}


	public void setBoardnum(int boardnum) {
		this.boardnum = boardnum;
	}


	public String getBname() {
		return bname;
	}


	public void setBname(String bname) {
		this.bname = bname;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getContents() {
		return contents;
	}


	public void setContents(String contents) {
		this.contents = contents;
	}


	public String getTime() {
		return time;
	}


	public void setTime(String time) {
		this.time = time;
	}


	public int getHit() {
		return hit;
	}


	public void setHit(int hit) {
		this.hit = hit;
	}
	
	
	
	
	
}

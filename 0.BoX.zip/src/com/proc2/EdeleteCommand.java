package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pro.EMPDAO;
import com.proc.EMPcommand;

public class EdeleteCommand implements EMPcommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		int cnt = 0;
		EMPDAO dao = new EMPDAO();
		String name = request.getParameter("Name");
		
		try {
			cnt = dao.Edelete(name);
			request.setAttribute("result", cnt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

}

package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pro.CDAO;
import com.pro.CDTO;
import com.proc.Ccommand;

public class CfindCommand implements Ccommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		CDAO dao = new CDAO();
		CDTO arr[] = null;
		String id = request.getParameter("Id");
		System.out.println(id);
		
		try {
			arr = dao.Cfind(id);
			request.setAttribute("Clist", arr);
			request.setAttribute("id", id);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}

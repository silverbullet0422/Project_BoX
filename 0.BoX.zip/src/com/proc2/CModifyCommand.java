package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pro.CDAO;
import com.pro.CDTO;
import com.proc.Ccommand;


public class CModifyCommand implements Ccommand {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
    	
        //request.setCharacterEncoding("euc-kr"); // 인코딩
        
    	CModifyCommand forward = new CModifyCommand();
        
        CDAO dao = CDAO.getInstance();
        
        // 세션이 가지고있는 로그인한 ID 정보를 가져온다
        HttpSession session = request.getSession();
        String id = session.getAttribute("sessionID").toString();
        
        // 수정할 정보를 자바빈에 세팅한다.
        CDTO customer = new CDTO();
       
        customer.setPw(request.getParameter("pw"));
        customer.setName(request.getParameter("name"));   
        
        try {
			dao.updateCustomer(customer);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 
        //forward.setRedirect(true);
           //forward.setNextPath("Result.do");
        
           // 회원정보 수정 성공 메시지를 세션에 담는다.
           session.setAttribute("msg", "0");
           
    }
}
 

package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pro.CDAO;
import com.pro.CDTO;
import com.proc.Ccommand;


public class CModifyFormCommand implements Ccommand {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
    	
        
		CModifyCommand forward = new CModifyCommand();
        
        // 세션이 가지고있는 로그인한 ID 정보를 가져온다
        HttpSession session = request.getSession();
        String id = session.getAttribute("sessionID").toString();
        
        // 수정할 회원정보를 가져온다.
        CDAO dao = CDAO.getInstance();
        CDTO customer = dao.getUserInfo(id);
        
        // ModifyFrom.jsp에 회원정보를 전달하기 위해 request에 MemberBean을 세팅한다.
        request.setAttribute("CInfo", customer);
        
        //forward.setRedirect(false);
        //forward.setNextPath("ModifyFrom.do");
        
        //return forward;
    }
}

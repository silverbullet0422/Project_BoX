package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pro.EMPDAO;
import com.pro.EMPDTO;
import com.proc.EMPcommand;

public class EfindCommand implements EMPcommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		EMPDAO dao = new EMPDAO();
		EMPDTO arr[] = null;
		String name = request.getParameter("Name");
		System.out.println(name);
		
		try {
			arr = dao.Efind(name);
			request.setAttribute("Elist", arr);
			request.setAttribute("name", name);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}

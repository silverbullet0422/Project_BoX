package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pro.CDAO;
import com.pro.CDTO;
import com.proc.Ccommand;

public class CinsertCommand implements Ccommand{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		CDAO dao = new CDAO();
		CDTO dto = new CDTO(
				request.getParameter("Name"),
				request.getParameter("Id"),
				request.getParameter("Pw"),
				request.getParameter("Address"),
				request.getParameter("Phonenum"),
				request.getParameter("Email"),
				Integer.parseInt(request.getParameter("Point"))
			);
		int cnt = 0;
		
		try {
			cnt = dao.insertC(dto);
			request.setAttribute("result", cnt);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
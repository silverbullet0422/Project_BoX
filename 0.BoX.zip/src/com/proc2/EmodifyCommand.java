package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pro.EMPDAO;
import com.pro.EMPDTO;
import com.proc.EMPcommand;


public class EmodifyCommand implements EMPcommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		EMPDAO dao = new EMPDAO();
		 
		EMPDTO dto = new EMPDTO();
		String Id = request.getParameter("Id");
	    String Pw = request.getParameter("Pw");
	    String Address =  request.getParameter("Address");
	    String Phonenum = request.getParameter("Phonenum");
	    String Email = request.getParameter("Email");
	    String Position = request.getParameter("Position");
	    String Dept = request.getParameter("Dept");
	    int Pay = Integer.parseInt(request.getParameter("Pay"));
	    String Memo =  request.getParameter("Memo");
		
		
		int cnt = 0;
		try {
			cnt = dao.modifyById(Id, Pw, Address, Phonenum, Email, Position, Dept, Pay, Memo);
			request.setAttribute("result", cnt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	

}

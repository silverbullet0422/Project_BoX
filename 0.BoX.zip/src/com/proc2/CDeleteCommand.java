package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pro.CDAO;
import com.pro.CDTO;
import com.proc.Ccommand;

public class CDeleteCommand implements Ccommand {

	   @Override
		public void execute(HttpServletRequest request, HttpServletResponse response) {
		
	        
	        //ActionForward forward = new ActionForward();
	        
	        // 세션이 가지고있는 로그인한 ID 정보를 가져온다
	        HttpSession session = request.getSession();
	        String id = (String)session.getAttribute("sessionID");
	        String pw = request.getParameter("pw");
	        
	        CDAO dao = CDAO.getInstance();
	        int check = dao.deleteCustomer(id, pw);
	        
	        if(check == 1){
	            session.invalidate(); // 회원정보 담긴 세션 삭제
	            //forward.setRedirect(true);
	            //forward.setNextPath("Result.do");
	        }
	        else{
	            System.out.println("회원 삭제 실패");
	            //return null;
	        }
	        
	        //return forward;
	    }
	
	
	
/*
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		int cnt = 0;
		CDAO dao = new CDAO();
		String id = request.getParameter("Id");
		
		try {
			cnt = dao.Cdelete(id);
			request.setAttribute("result", cnt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
*/
}

package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pro.EMPDAO;
import com.pro.EMPDTO;
import com.proc.EMPcommand;

public class EinsertCommand implements EMPcommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		EMPDAO dao = new EMPDAO();
		EMPDTO dto = new EMPDTO(
				request.getParameter("Name"),
				request.getParameter("Id"),
				request.getParameter("Pw"),
				request.getParameter("Address"),
				request.getParameter("Phonenum"),
				request.getParameter("Email"),
				request.getParameter("Position"),	
				request.getParameter("Dept"),
				Integer.parseInt(request.getParameter("Pay")),
				request.getParameter("Memo")
			);
		int cnt = 0;
		
		try {
			cnt = dao.insertEMP(dto);
			request.setAttribute("result", cnt);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}

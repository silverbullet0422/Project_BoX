package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pro.CDAO;
import com.pro.CDTO;
import com.proc.Ccommand;


public class CInfoCommand implements Ccommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
	
        // 세션이 가지고있는 로그인한 ID 정보를 가져온다
        HttpSession session = request.getSession();
        String id = (String)session.getAttribute("sessionID");
        
        // 그 아이디 해당하는 회원정보를 가져온다.
        CDAO dao = CDAO.getInstance();
        CDTO customer = dao.getUserInfo(id);
        
        // UserInfoForm.jsp에 회원정보를 전달하기 위해 request에 CTO 세팅한다.
        request.setAttribute("CInfo", customer);
        
        //forward.setRedirect(false);
        //forward.setNextPath("CInfoForm.go");
        
        
        //return forward;
    }
 
}





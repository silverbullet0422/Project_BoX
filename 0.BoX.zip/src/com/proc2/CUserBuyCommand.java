package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pro.CDAO;
import com.pro.CDTO;
import com.proc.Ccommand;


public class CUserBuyCommand implements Ccommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
        String id = (String)session.getAttribute("sessionID");
	    System.out.println(id);
		CDAO dao = new CDAO();
		CDTO [] arr = null;
		
		try {
			arr = dao.UserBuy(id);
			request.setAttribute("list", arr);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
	}

}

package com.proc2;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pro.EMPDAO;
import com.pro.EMPDTO;
import com.proc.EMPcommand;

public class ElistCommand implements EMPcommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		EMPDAO dao = new EMPDAO();
		EMPDTO [] arr = null;
		
		try {
			arr = dao.select();
			request.setAttribute("list", arr);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
	}

}

// Emp Board用 BoardDao

package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.BoardBean;
import com.db.MyOracle;

public class BoardDao {

	// 掲示板 メイン(一般用) 一つ 追加
	public void insertBoard(BoardBean boardBean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int num = 0; // テキストナンバー
		
		try {
			con = MyOracle.getConnection();
			// テキスト num を求める. テキストがない場合１
			// テキストがある場合、一番最新のテキスト番号(一番大きい番号）＋１
			sql = "SELECT MAX(num) FROM empboard";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				// テキストの最大値＋１, getInt中の数値はインデックス(1番目)
				num = rs.getInt(1) + 1;
			} else {
				num = 1;
			}
			pstmt.close();
			rs.close();
			// メインテキスト(一般のテキスト) num == re_ref と同じく入力
			
			sql = "INSERT INTO empboard (num, emp_id,"
					+ " title, emp_contents, re_ref, re_lev, re_seq, hit, reg_date) ";
			sql += "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, num); // テキストナンバー 
			pstmt.setString(2, boardBean.getEmp_id());
			pstmt.setString(3, boardBean.getTitle());
			pstmt.setString(4, boardBean.getEmp_contents());
			pstmt.setInt(5, num); // re_ref == num
			pstmt.setInt(6, 0); // re_lev 同じグループのインデント
			pstmt.setInt(7, 0); // re_seq 
			pstmt.setInt(8, 0); // hit数
			pstmt.setTimestamp(9, boardBean.getReg_date());
			pstmt.executeQuery();
					
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
	} // end insertBoard
	
	
	// 掲示板のテキストをもってくる
	public List<BoardBean> getBoards(int startRow, int endRow){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<BoardBean> list = new ArrayList<>();
		// よくできる文字の連結に対してString都は違うガベージ客体を作る
		StringBuilder sb = new StringBuilder();
		
		
		try {
			con = MyOracle.getConnection();
			sb.append("select a.* ");
			sb.append("from ");
			sb.append("    (select rownum as rnum, a.* ");
			sb.append("    from (select * from empboard order by re_ref desc, re_seq asc) a ");
			sb.append("    where rownum <= ?) a ");
			sb.append("where rnum >= ? ");
			
			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, endRow);
			pstmt.setInt(2, startRow);
			//実行
			rs = pstmt.executeQuery();
			// rs => ジャバビンにセーブ => listに一つ追加
			while (rs.next()) {
				//ジャバビンの客体生成の準備
				BoardBean boardBean = new BoardBean();
				// rs => ジャバビンにセーブ
				boardBean.setEmp_contents(rs.getString("emp_contents"));
				boardBean.setEmp_id(rs.getString("emp_id"));
				boardBean.setNum(rs.getInt("num"));
				boardBean.setRe_lev(rs.getInt("re_lev"));
				boardBean.setRe_ref(rs.getInt("re_ref"));
				boardBean.setRe_seq(rs.getInt("re_seq"));
				boardBean.setHit(rs.getInt("hit"));
				boardBean.setReg_date(rs.getTimestamp("reg_date"));
				boardBean.setTitle(rs.getString("title"));
				// ジャバビン => list 一間を追加
				list.add(boardBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
		return list;
	}
		
	//全体のテキストの数をもって来る
	public int getBoardCount() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int count = 0;
			
		try {
			con = MyOracle.getConnection();
			// sql 全体のテキストの数をもって来る
			sql = "SELECT COUNT(*) FROM empboard";
			pstmt = con.prepareStatement(sql);
			//実行 rs
			rs = pstmt.executeQuery();
			// rsにデータがある場合
				
			if(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
		return count;
	}
	
	// ヒット数を１つ上げる
	public void updateHit(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql ="";
		
		try {
			con = MyOracle.getConnection();
			//sql update numに当たるヒット数１を上げる
			// (既存のヒット数から +1)
			sql = "UPDATE empboard SET hit = hit+1 WHERE num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeQuery();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, null);
		}
	}
	
	// テキストを一つもって来る、テキストのせいさい詳細内容を見る
	public BoardBean getBoard(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		BoardBean boardBean = null;
		
		try {
			con = MyOracle.getConnection();
			sql = "SELECT * FROM empboard WHERE num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				boardBean = new BoardBean();
				boardBean.setEmp_contents(rs.getString("emp_contents"));
				boardBean.setEmp_id(rs.getString("emp_id"));
				boardBean.setNum(rs.getInt("num"));
				boardBean.setRe_lev(rs.getInt("re_lev"));
				boardBean.setRe_ref(rs.getInt("re_ref"));
				boardBean.setRe_seq(rs.getInt("re_seq"));
				boardBean.setHit(rs.getInt("hit"));
				boardBean.setReg_date(rs.getTimestamp("reg_date"));
				boardBean.setTitle(rs.getString("title"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
		return boardBean;
	} // getBoard
	
	// 掲示板修正
	public int updateBoard(BoardBean boardBean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int check = 0;
		try {
			con = MyOracle.getConnection();
					
					sql = "UPDATE empboard SET title=?, emp_contents=? WHERE num=?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, boardBean.getTitle());
					pstmt.setString(2, boardBean.getEmp_contents());
					pstmt.setInt(3, boardBean.getNum());
					pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
		return check;
	} // updateBoard
	
	// テキストを消す
	public int deleteBoard(int num/*, String passwd*/) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int check = 0;
		
		try {
			con = MyOracle.getConnection();
					sql = "DELETE FROM empboard WHERE num=?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, num);
					pstmt.executeUpdate();
					
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
		return check;
	}
	
	// 返事書き(re_seqを 1つずつ アップデート後返事を insert)
	public void reInsertBoard(BoardBean boardBean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int num = 0;
		
		try {
			con = MyOracle.getConnection();
			// update & insert 한개의 처리단위인데 오류발생시 앞쪽의 트렌젝션만 수행되는 경우 데이터 변경이 없기 위해
			// 트랜잭션 관리 기법
			// 기본설정인 자동커밋을 수동커밋으로 제어함
			
			con.setAutoCommit(false);
			// sql グループ内の返事の順を再配置
			// update re_seq
			sql = "UPDATE empboard SET re_seq=re_seq+1 WHERE re_ref=? AND re_seq > ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, boardBean.getRe_ref());
			pstmt.setInt(2, boardBean.getRe_seq());
			pstmt.executeUpdate();
			
			pstmt.close(); pstmt = null;
			sql = "SELECT MAX(num) FROM empboard";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				num = rs.getInt(1) + 1;
				boardBean.setNum(num);
			} else {
				num = 1;
			}
			
			pstmt.close(); pstmt = null;
			sql = "INSERT INTO empboard(num, emp_id, title, emp_contents,"
					+ "re_ref, re_lev,re_seq, hit, reg_date)";
			sql+= "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,  num);  
			pstmt.setString(2, boardBean.getEmp_id());
			pstmt.setString(3, boardBean.getTitle());
			pstmt.setString(4, boardBean.getEmp_contents());
			pstmt.setInt(5, boardBean.getRe_ref()); 
			pstmt.setInt(6, boardBean.getRe_lev()+1);
			pstmt.setInt(7, boardBean.getRe_seq()+1);
			pstmt.setInt(8, 0); 
			pstmt.setTimestamp(9, boardBean.getReg_date());
			pstmt.executeUpdate();
			
			
			con.commit();
			// autoCommitの基本属性をtrueに変更
			con.setAutoCommit(true);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				// エラー発生時もとに状態に戻す
				con.rollback();
 			} catch(SQLException e1) {
 				e1.printStackTrace();
 			}
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
	} // reInsertBoard()
	
} // end class

// User Board用 BoardDao

package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.BoardBean2;
import com.db.MyOracle;

public class BoardDao2 {

	public void insertBoard2(BoardBean2 boardBean2) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int num = 0; 
		
		try {
			con = MyOracle.getConnection();
			sql = "SELECT MAX(num) FROM userboard";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				num = rs.getInt(1) + 1;
			} else {
				num = 1;
			}
			pstmt.close();
			rs.close();
			
			sql = "INSERT INTO userboard (num, user_id,"
					+ " title, user_contents, re_ref, re_lev, re_seq, hit, reg_date) ";
			sql += "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, num);  
			pstmt.setString(2, boardBean2.getUser_id());
			pstmt.setString(3, boardBean2.getTitle());
			pstmt.setString(4, boardBean2.getUser_contents());
			pstmt.setInt(5, num); // re_ref == num
			pstmt.setInt(6, 0); 
			pstmt.setInt(7, 0); 
			pstmt.setInt(8, 0); 
			pstmt.setTimestamp(9, boardBean2.getReg_date());
			pstmt.executeQuery();
					
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
	} // end insertBoard
	
	
	public List<BoardBean2> getBoards2(int startRow, int endRow){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<BoardBean2> list = new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		
		
		try {
			con = MyOracle.getConnection();
			sb.append("select a.* ");
			sb.append("from ");
			sb.append("    (select rownum as rnum, a.* ");
			sb.append("    from (select * from userboard order by re_ref desc, re_seq asc) a ");
			sb.append("    where rownum <= ?) a ");
			sb.append("where rnum >= ? ");
			
			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, endRow);
			pstmt.setInt(2, startRow);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				BoardBean2 boardBean2 = new BoardBean2();
				boardBean2.setUser_contents(rs.getString("user_contents"));
				boardBean2.setUser_id(rs.getString("user_id"));
				boardBean2.setNum(rs.getInt("num"));
				boardBean2.setRe_lev(rs.getInt("re_lev"));
				boardBean2.setRe_ref(rs.getInt("re_ref"));
				boardBean2.setRe_seq(rs.getInt("re_seq"));
				boardBean2.setHit(rs.getInt("hit"));
				boardBean2.setReg_date(rs.getTimestamp("reg_date"));
				boardBean2.setTitle(rs.getString("title"));
				list.add(boardBean2);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
		return list;
	}
		
	public int getBoardCount2() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int count = 0;
			
		try {
			con = MyOracle.getConnection();
			sql = "SELECT COUNT(*) FROM userboard";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
				
			if(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
		return count;
	}
	
	public void updateHit2(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql ="";
		
		try {
			con = MyOracle.getConnection();
			sql = "UPDATE userboard SET hit = hit+1 WHERE num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeQuery();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, null);
		}
	}
	
	public BoardBean2 getBoard2(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		BoardBean2 boardBean2 = null;
		
		try {
			con = MyOracle.getConnection();
			sql = "SELECT * FROM userboard WHERE num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				boardBean2 = new BoardBean2();
				boardBean2.setUser_contents(rs.getString("user_contents"));
				boardBean2.setUser_id(rs.getString("user_id"));
				boardBean2.setNum(rs.getInt("num"));
				boardBean2.setRe_lev(rs.getInt("re_lev"));
				boardBean2.setRe_ref(rs.getInt("re_ref"));
				boardBean2.setRe_seq(rs.getInt("re_seq"));
				boardBean2.setHit(rs.getInt("hit"));
				boardBean2.setReg_date(rs.getTimestamp("reg_date"));
				boardBean2.setTitle(rs.getString("title"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
		return boardBean2;
	} // getBoard
	
	public int updateBoard2(BoardBean2 boardBean2) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int check = 0;
		try {
			con = MyOracle.getConnection();
					sql = "UPDATE userboard SET title=?, user_contents=? WHERE num=?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, boardBean2.getTitle());
					pstmt.setString(2, boardBean2.getUser_contents());
					pstmt.setInt(3, boardBean2.getNum());
					pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
		return check;
	} // updateBoard
	
	public int deleteBoard2(int num/*, String passwd*/) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int check = 0;
		
		try {
			con = MyOracle.getConnection();
					sql = "DELETE FROM userboard WHERE num=?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, num);
					pstmt.executeUpdate();
					
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
		return check;
	}
	
	public void reInsertBoard2(BoardBean2 boardBean2) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int num = 0;
		
		try {
			con = MyOracle.getConnection();
			
			con.setAutoCommit(false);
			sql = "UPDATE userboard SET re_seq=re_seq+1 WHERE re_ref=? AND re_seq > ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, boardBean2.getRe_ref());
			pstmt.setInt(2, boardBean2.getRe_seq());
			pstmt.executeUpdate();
			
			pstmt.close(); pstmt = null;
			sql = "SELECT MAX(num) FROM userboard";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				num = rs.getInt(1) + 1;
				boardBean2.setNum(num);
			} else {
				num = 1;
			}
			pstmt.close(); pstmt = null;
			sql = "INSERT INTO userboard(num, user_id, title, user_contents,"
					+ "re_ref, re_lev,re_seq, hit, reg_date)";
			sql+= "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,  num);  
			pstmt.setString(2, boardBean2.getUser_id());
			pstmt.setString(3, boardBean2.getTitle());
			pstmt.setString(4, boardBean2.getUser_contents());
			pstmt.setInt(5, boardBean2.getRe_ref()); 
			pstmt.setInt(6, boardBean2.getRe_lev()+1); 
			pstmt.setInt(7, boardBean2.getRe_seq()+1);
			pstmt.setInt(8, 0); 
			pstmt.setTimestamp(9, boardBean2.getReg_date());
			pstmt.executeUpdate();
			
			con.commit();
			con.setAutoCommit(true);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
 			} catch(SQLException e1) {
 				e1.printStackTrace();
 			}
		} finally {
			MyOracle.closeJDBC(con, pstmt, rs);
		}
	} // reInsertBoard()
	
} // end class

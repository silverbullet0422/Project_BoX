package com.proc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface EMPcommand {
	void execute(HttpServletRequest request, HttpServletResponse response);
}

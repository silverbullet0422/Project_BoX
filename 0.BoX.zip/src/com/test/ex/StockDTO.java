package com.test.ex;

public class StockDTO {
	private int Item_Num;	// 재고 번호
	private String Item_Name;	// 재고품 이름
	private String Item_Class;	// 재고품 분류
	private int Item_Volume;	// 재고품 수량
	private String Item_Img;	// 아이템 이미지 이름 --> 나중에 이것을 기준으로 이미지를 연결시킨다.
	private int Buy_Price;	// 구매가격
	private int Sell_Price;	// 판매가격
	
	// 기본생성자
	public StockDTO() {
		super();
	}
	
	// 멤버변수 생성자
	public StockDTO(String Item_Name, String Item_Class, int Item_Volume, String Item_Img,
			int Buy_Price, int Sell_Price) {
		super();
		this.Item_Name = Item_Name;
		this.Item_Class = Item_Class;
		this.Item_Volume = Item_Volume;
		this.Item_Img = Item_Img;
		this.Buy_Price = Buy_Price;
		this.Sell_Price = Sell_Price;
	}
	
	public StockDTO(int Item_Num, String Item_Name, String Item_Class, int Item_Volume, String Item_Img,
			int Buy_Price, int Sell_Price) {
		super();
		this.Item_Num = Item_Num;
		this.Item_Name = Item_Name;
		this.Item_Class = Item_Class;
		this.Item_Volume = Item_Volume;
		this.Item_Img = Item_Img;
		this.Buy_Price = Buy_Price;
		this.Sell_Price = Sell_Price;
	}

	
	
	public int getItem_Num() {
		return Item_Num;
	}

	public void setItem_Num(int Item_Num) {  
		this.Item_Num = Item_Num;
	}

	public String getItem_Name() {
		return Item_Name;
	}

	public void setItem_Name(String Item_Name) {
		this.Item_Name = Item_Name;
	}

	public String getItem_Class() {
		return Item_Class;
	}

	public void setItem_Class(String Item_Class) {
		this.Item_Class = Item_Class;
	}

	public int getItem_Volume() {
		return Item_Volume;
	}

	public void setItem_Volume(int Item_Volume) {
		this.Item_Volume = Item_Volume;
	}

	public String getItem_Img() {
		return Item_Img;
	}

	public void setItem_Img(String Item_Img) {
		this.Item_Img = Item_Img;
	}

	public int getBuy_Price() {
		return Buy_Price;
	}

	public void setBuy_Price(int Buy_Price) {
		this.Buy_Price = Buy_Price;
	}

	public int getSell_Price() {
		return Sell_Price;
	}

	public void setSell_Price(int Sell_Price) {
		this.Sell_Price = Sell_Price;
	}
	
	
} // end class







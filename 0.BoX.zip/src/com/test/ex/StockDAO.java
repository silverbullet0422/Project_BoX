package com.test.ex;

import java.sql.*;
import java.util.*;

public class StockDAO {
	Connection conn;	// 커넥션 개체 생성
	PreparedStatement pstmt;	// psmt객체 생성
	ResultSet rs;	// rs객체 생성
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String uid = "scott";
	String pwd = "tiger";
	
	// DAO 객체가 '생성' 될때 connection 생성
	public StockDAO() {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, uid, pwd);
			System.out.println("데이터베이스 연결!!");
		} catch (Exception e) {			
			e.printStackTrace();
		}	
	} // end Constructor()
	

	public int insertStock(String Item_Name, String Item_Class, int Item_Volume, String Item_Img,
			int Buy_Price, int Sell_Price) throws SQLException{	 // insertStock 메서드 작성
		
		int cnt = 0;	// 리턴값 설정
			
		try {
			String sql = "INSERT INTO STOCK(Item_Num, Item_Name, Item_Class, Item_Volume, Item_Img, Buy_Price, Sell_Price) " +
					"VALUES(STOCK_SEQ.nextval, ?, ?, ?, ?, ?, ?)";
			
			pstmt = conn.prepareStatement(sql);	// pstmt 
			
			pstmt.setString(1, Item_Name);
			pstmt.setString(2, Item_Class);
			pstmt.setInt(3, Item_Volume);
			pstmt.setString(4, Item_Img);
			pstmt.setInt(5, Buy_Price);
			pstmt.setInt(6, Sell_Price);
			
			cnt = pstmt.executeUpdate();
			
		} finally {
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		}
		
		return cnt;
	}
	
	public int insertStock(StockDTO dto) throws SQLException{
		String Item_Name = dto.getItem_Name();
		String Item_Class = dto.getItem_Class();
		int Item_Volume = dto.getItem_Volume();
		String Item_Img = dto.getItem_Img();
		int Buy_Price = dto.getBuy_Price();
		int Sell_Price = dto.getSell_Price();
		
		int cnt = this.insertStock(Item_Name, Item_Class, Item_Volume, Item_Img, Buy_Price, Sell_Price);
		return cnt;
	}
	
	
	public StockDTO[] createArray(ResultSet rs) throws SQLException{
		
		ArrayList<StockDTO> list = new ArrayList<StockDTO>();
		
		while(rs.next()) {
			int Item_Num = rs.getInt(1);
			String Item_Name = rs.getString(2);
			String Item_Class = rs.getString(3);
			int Item_Volume = rs.getInt(4);
			String Item_Img = rs.getString(5);  
			int Buy_Price = rs.getInt(6);  
			int Sell_Price = rs.getInt(7);   
			
			StockDTO dto = new StockDTO(Item_Name, Item_Class, Item_Volume, Item_Img, Buy_Price, Sell_Price);
			dto.setItem_Num(Item_Num);
			
			list.add(dto);
		} // end while
		
		
		StockDTO [] arr = new StockDTO[list.size()];
		list.toArray(arr);
		return arr;
	} // end createArray()
	
	
	public StockDTO[] select() throws SQLException{
		
		try {
			String sql = "SELECT * FROM STOCK ORDER BY ITEM_NUM DESC"; 
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(); 
			 
			return createArray(rs);  // MemberDTO[] 리턴
			
		} finally {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		}
		
		
	} // end select()
	
	
	// find
	public StockDTO[] findByName(String name) throws SQLException{
		try{
			String sql="SELECT * FROM STOCK WHERE Item_Name=? ORDER BY Item_Num DESC";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();	

			StockDTO arr[] = createArray(rs); 
			return arr; 
		}finally{
			if(rs !=null) rs.close();
			if(pstmt!=null) pstmt.close();
			if(conn !=null) conn.close();
		}
	}	// end findByName
	
	// delete
	public int deleteById(String Item_Num) throws SQLException{
		try{
			String sql="DELETE FROM STOCK WHERE Item_Num=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, Item_Num);
			int cnt = pstmt.executeUpdate();
			return cnt;
		}finally{
			if(pstmt !=null) pstmt.close();
			if(conn !=null) conn.close();
		}

	}	// end deleteById
	
	// modify
	public int modifyById(String Item_Name, String Item_Class, 
				int Item_Volume, String Item_Img, int Buy_Price, int Sell_Price, int Item_Num) throws SQLException {
		try {
			int cnt = 0;
			String sql = "update stock set item_name = ?, item_class = ?, item_volume = ?, item_img = ?, buy_price = ?, sell_price = ? where item_num = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, Item_Name);
			pstmt.setString(2, Item_Class);
			pstmt.setInt(3, Item_Volume);
			pstmt.setString(4, Item_Img);
			pstmt.setInt(5, Buy_Price);
			pstmt.setInt(6, Sell_Price);
			pstmt.setInt(7, Item_Num);
			cnt = pstmt.executeUpdate();
			return cnt;
		} finally {
			if(rs !=null) rs.close();
			if(pstmt!=null) pstmt.close();
			if(conn !=null) conn.close();
		}
	}	// end modifyById
	
	public int modifyById(StockDTO dto) throws SQLException{
		String Item_Name = dto.getItem_Name();
		String Item_Class = dto.getItem_Class();
		int Item_Volume = dto.getItem_Volume();
		String Item_Img = dto.getItem_Img();
		int Buy_Price = dto.getBuy_Price();
		int Sell_Price = dto.getSell_Price();
		int Item_Num = dto.getItem_Num();
		
		int cnt = this.modifyById(Item_Name, Item_Class, Item_Volume, Item_Img, Buy_Price, Sell_Price, Item_Num);
		return cnt;
	}
	



} // end DAO
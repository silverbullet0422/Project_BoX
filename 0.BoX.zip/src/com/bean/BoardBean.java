// Emp Board用 BoardBean

package com.bean;

import java.sql.Timestamp;

public class BoardBean {
	private int num;
	private String emp_id;
	private String title;
	private String emp_contents;
	private Timestamp reg_date;
	private int hit;
	private int re_ref; // テキストグループ
	private int re_lev; // インデントレベル
	private int re_seq; // グループ内順序

	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getEmp_contents() {
		return emp_contents;
	}
	public void setEmp_contents(String emp_contents) {
		this.emp_contents = emp_contents;
	}
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public int getRe_ref() {
		return re_ref;
	}
	public void setRe_ref(int re_ref) {
		this.re_ref = re_ref;
	}
	public int getRe_lev() {
		return re_lev;
	}
	public void setRe_lev(int re_lev) {
		this.re_lev = re_lev;
	}
	public int getRe_seq() {
		return re_seq;
	}
	public void setRe_seq(int re_seq) {
		this.re_seq = re_seq;
	}
	
}

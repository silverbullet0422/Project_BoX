// User Board用 BoardBean

package com.bean;

import java.sql.Timestamp;

public class BoardBean2 {
	private int num;
	private String user_id;
	private String title;
	private String user_contents;
	private Timestamp reg_date;
	private int hit;
	private int re_ref; // テキストグループ
	private int re_lev; // インデントレベル
	private int re_seq; // グループ内順序

	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUser_contents() {
		return user_contents;
	}
	public void setUser_contents(String user_contents) {
		this.user_contents = user_contents;
	}
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public int getRe_ref() {
		return re_ref;
	}
	public void setRe_ref(int re_ref) {
		this.re_ref = re_ref;
	}
	public int getRe_lev() {
		return re_lev;
	}
	public void setRe_lev(int re_lev) {
		this.re_lev = re_lev;
	}
	public int getRe_seq() {
		return re_seq;
	}
	public void setRe_seq(int re_seq) {
		this.re_seq = re_seq;
	}
	
}

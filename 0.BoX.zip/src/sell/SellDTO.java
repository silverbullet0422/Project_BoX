package sell;

import java.sql.Date;	// 이거 sql.date인지 util.date인지

// 계층간 데이터교환을 위해서 생성
// DAO는 DTO를 통해 데이터를 교환한다.
public class SellDTO {

	private int Sell_Num; // 판매번호
	private int Item_Num; // 재고제품번호
	private Date Sell_Date;
	private int Sell_Volume;
	private String Sell_Place;
	private int User_Num;
	
	// 추가 출력
	private int Sell_Price;
	private int Item_Volume;
	private String Item_Name;
	
	// 기본 생성자
	public SellDTO() {
		super();
	}
	
	// 멤버변수 생성자
	public SellDTO(int Item_Num, int Sell_Volume, String Sell_Place, int User_Num) {
		super();
		this.Item_Num = Item_Num;
		this.Sell_Volume = Sell_Volume;
		this.Sell_Place = Sell_Place;
		this.User_Num = User_Num;
	}
	
	// modify용 생성자 오버로딩
	public SellDTO(int Sell_Num, int Item_Num, int Sell_Volume, String Sell_Place, int User_Num) {
		super();
		this.Sell_Num = Sell_Num;
		this.Item_Num = Item_Num;
		this.Sell_Place = Sell_Place;
		this.Sell_Volume = Sell_Volume;
		this.User_Num = User_Num;
	}
	// volume change용 생성자 오버로딩
	public SellDTO(int Item_Num, int Sell_Volume) {
		super();
		this.Item_Num = Item_Num;
		this.Sell_Volume = Sell_Volume;
	}
	
	// input_point용 생성자 오버로딩
	public SellDTO(int User_Num) {
		super();
		this.User_Num = User_Num;
	}
	//getter setter
	public String getItem_Name() {
		return Item_Name;
	}

	public void setItem_Name(String Item_Name) {
		this.Item_Name = Item_Name;
	}

	public int getSell_Price() {
		return Sell_Price;
	}

	public void setSell_Price(int Sell_Price) {
		this.Sell_Price = Sell_Price;
	}

	public int getItem_Volume() {
		return Item_Volume;
	}

	public void setItem_Volume(int Item_Volume) {
		this.Item_Volume = Item_Volume;
	}

	public int getSell_Num() {
		return Sell_Num;
	}

	public void setSell_Num(int Sell_Num) {
		this.Sell_Num = Sell_Num;
	}
	
	public int getItem_Num() {
		return Item_Num;
	}

	public void setItem_Num(int Item_Num) {
		this.Item_Num = Item_Num;
	}

	public Date getSell_Date() {
		return Sell_Date;
	}

	public void setSell_Date(Date Sell_Date) {
		this.Sell_Date = Sell_Date;
	}

	public int getSell_Volume() {
		return Sell_Volume;
	}

	public void setSell_Volume(int Sell_Volume) {
		this.Sell_Volume = Sell_Volume;
	}

	public String getSell_Place() {
		return Sell_Place;
	}

	public void setSell_Place(String Sell_Place) {
		this.Sell_Place = Sell_Place;
	}

	public int getUser_Num() {
		return User_Num;
	}

	public void setUser_Num(int User_Num) {
		this.User_Num = User_Num;
	}
	
} // end of sellDTO

package sell;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sell.SellDAO;
import sell.SellDTO;

public class Sell_point_command implements Sell_command {

	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		SellDAO dao = new SellDAO();
		SellDTO point = new SellDTO(
				Integer.parseInt(request.getParameter("User_Num"))
				);
		int cnt = 0;
		
		try {
			cnt = dao.inputPoint(point);
			request.setAttribute("result", cnt);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

}

package sell;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("*.sell")	// 어떤 리퀘스트던지 끝이 .sell로 끝나면 모두 받아 들인다.
public class Sell_controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Sell_controller() {	// 기초 생성자
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void actionDo(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {
		System.out.println("actionDo를 호출한다");
		
		request.setCharacterEncoding("UTF-8");
		// 1. URL로부터 contextPath와 command를 분리한다.
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		
		// 2. 시범출력
		System.out.println(uri);	// URI부분 출력
		System.out.println(conPath);	 // conpath 출력
		System.out.println(com);		// command부분 출력 --> ~~.sell 로 출력
		
		// 3. 컨트롤러는 어떤 command를 수행할지, 어떤 view페이지로 연결 시킬것인지 판단
		String viewPage = null;	// 보여줄 페이지
		Sell_command Sell_command = null;	// 어떤 로직(command)로 수행할지
		
// 4. 컨트롤러는 커맨드에 따라 로직을 수행하고 결과값을 보여준다
		if(com.equals("/SELL/sell_list.sell")) {
			Sell_command = new Sell_list_command();
			Sell_command.execute(request, response);
			viewPage = "sell_list.jsp";
			
		} else if(com.equals("/SELL/sell_insert.sell")) {
			Sell_command = new Sell_insert_command();
			Sell_command.execute(request, response);
			viewPage = "sell_insert.jsp";
			
		} else if(com.equals("/SELL/sell_delete.sell")) {
			Sell_command = new Sell_delete_command();
			Sell_command.execute(request, response);
			viewPage = "sell_delete.jsp";
			
		}  else if(com.equals("/SELL/sell_modify.sell")) {
			Sell_command = new Sell_modify_command();
			Sell_command.execute(request, response);
			viewPage = "sell_modify.jsp";
			
		}	else if(com.equals("/SELL/sell_change.sell")) {
			Sell_command = new Sell_change_command();
			Sell_command.execute(request, response);
			viewPage = "sell_change.jsp";
			
		}	else if(com.equals("/SELL/input_point.sell")) {
			Sell_command = new Sell_point_command();
			Sell_command.execute(request, response);
			viewPage = "input_point.jsp";
		}
		
		
		// 5. request를 forward 한다.
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);
				
	} // end actionDo
 	
	
	
}	// end sell_controller

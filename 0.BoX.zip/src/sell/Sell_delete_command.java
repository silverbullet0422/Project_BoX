package sell;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sell.SellDAO;


public class Sell_delete_command implements Sell_command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		SellDAO dao = new SellDAO();
		int cnt = 0;
		
		try {
			cnt = dao.deleteById(request.getParameter("id"));
			request.setAttribute("result", cnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}	// end delete_command

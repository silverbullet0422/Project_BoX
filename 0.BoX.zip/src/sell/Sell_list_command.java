package sell;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Sell_list_command implements Sell_command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		SellDAO dao = new SellDAO();
		SellDTO[] sel = null;
		
		try {
			sel = dao.select();
			request.setAttribute("list", sel);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

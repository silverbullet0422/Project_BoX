package sell;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sell.SellDAO;
import sell.SellDTO;

public class Sell_volume_change implements Sell_command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		SellDAO dao = new SellDAO();
		SellDTO dto = new SellDTO(
				Integer.parseInt(request.getParameter("Item_Num")),
				Integer.parseInt(request.getParameter("Sell_Volume"))
				);
		int cnt = 0;
		
		try {
			cnt = dao.changeVolume(dto);
			request.setAttribute("result2", cnt);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}	// end sell_volume_change()

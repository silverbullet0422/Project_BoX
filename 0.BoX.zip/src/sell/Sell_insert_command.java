package sell;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sell.SellDAO;
import sell.SellDTO;
public class Sell_insert_command implements Sell_command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		SellDAO dao = new SellDAO();
		SellDTO sell = new SellDTO(
				Integer.parseInt(request.getParameter("Item_Num")),
				Integer.parseInt(request.getParameter("Sell_Volume")),
				request.getParameter("Sell_Place"),
				Integer.parseInt(request.getParameter("User_Num"))
				//Integer.parseInt(request.getParameter("User_Num")),
				//Integer.parseInt(request.getParameter("Item_Num")),
				//Integer.parseInt(request.getParameter("Sell_Volume")),
				//Integer.parseInt(request.getParameter("Item_Num"))
				
				);
		
		int cnt = 0;
		
		try {
			
			cnt = dao.insertSell(sell);
			
			request.setAttribute("result", cnt);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

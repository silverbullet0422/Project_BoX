package sell;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sell.SellDAO;
import sell.SellDTO;

public class Sell_change_command implements Sell_command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		SellDAO dao = new SellDAO();
		SellDTO change = new SellDTO(
				Integer.parseInt(request.getParameter("Item_Num")),
				Integer.parseInt(request.getParameter("Sell_Volume"))
				);
		int cnt = 0;
		
		try {
			cnt = dao.changeVolume(change);
			request.setAttribute("result", cnt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

}

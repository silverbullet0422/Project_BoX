package sell;

import java.sql.*;
import java.sql.Date;
import java.util.*;

public class SellDAO {
	Connection conn;	// 커넥션 개체 생성
	PreparedStatement pstmt; // pstmt객체 생성
	ResultSet rs;
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String uid = "scott";
	String pwd = "tiger";
	
	// DAO 객체가 생성 되면서 connection이 만들어진다. 
	public SellDAO() { 
		try {
			Class.forName(driver);	// Oracle Driver를 로드한다.
			conn = DriverManager.getConnection(url, uid, pwd);	// JDBC라이브러리를 사용해 커넥션을 생성한다.
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	} // end Constructor();
	
	//TODO LIST -- 판매내역 리스트
	
//TODO INSERT -- 판매정보 입력(고객이 구입한것을 반영)
	// 고객우선이 아니라 점포 우선으로 일단 설정
	// 이쪽에서 입력된 값을 바탕으로 고객 테이블, 고객구매테이블이 수정된다.
	public int insertSell(int Item_Num, int Sell_Volume, String Sell_Place, int User_Num) throws SQLException {
		int cnt = 0; // 리턴값 설정
		
		try {
			String sql = "INSERT all "
						 	+"INTO SELL(Sell_Num, Item_Num, Sell_Date, Sell_Volume, Sell_Place, User_Num) "
						 		+"VALUES(SELL_SEQ.nextval, ?, sysdate, ?, ?, ?) "
						 	+"INTO USER_PURCHASE(purchase_num, user_num, Item_num, total_price, purchase_date) "
						 		+"values (User_Purchase_SEQ.nextval, ?, ?, (?*(select sell_price from stock where Item_Num = ?)), sysdate) "
						 	+"SELECT * FROM DUAL";
			pstmt = conn.prepareStatement(sql);	// pstmt객체에 sql구문(insert) 적용
			pstmt.setInt(1, Item_Num);
			pstmt.setInt(2, Sell_Volume);
			pstmt.setString(3, Sell_Place);
			pstmt.setInt(4, User_Num);
			pstmt.setInt(5, User_Num);
			pstmt.setInt(6, Item_Num);
			pstmt.setInt(7, Sell_Volume);
			pstmt.setInt(8, Item_Num);
			
//			String sql = "INSERT INTO SELL(Sell_Num, Item_Num, Sell_Date, Sell_Volume, Sell_Place, User_Num) "
//				 		+"VALUES(SELL_SEQ.nextval, ?, sysdate, ?, ?, ?) ";
//	 		pstmt = conn.prepareStatement(sql);	// pstmt객체에 sql구문(insert) 적용
//			pstmt.setInt(1, Item_Num);
//			pstmt.setInt(2, Sell_Volume);
//			pstmt.setString(3, Sell_Place);
//			pstmt.setInt(4, User_Num);
				 		
			
			
			cnt = pstmt.executeUpdate(); // 실행되면 '1'출력
			
		} finally {	// pstmt, conn 값이 들어왔으면(실행되었으면) 다 쓰고 자원반환하라
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		} 
		
		return cnt;
	} // end insertSell()
	
	// insertSell 오버라이드 : DTO와 연결
	public int insertSell(SellDTO dto) throws SQLException{
		int Item_Num = dto.getItem_Num();
		int Sell_Volume = dto.getSell_Volume();
		String Sell_Place = dto.getSell_Place();
		int User_Num = dto.getUser_Num();
		
		int cnt = this.insertSell(Item_Num, Sell_Volume, Sell_Place, User_Num);
		return cnt;	// dto를 통해 끌어온 값을 cnt에 저장
		
	}	// end inserSell
	
	public int inputPoint(int User_Num) throws SQLException {
		int cnt = 0;
		
		try {
			String sql = "update customer set point ="
					+ " (select sum(Total_Price)/100 from user_purchase where User_Num = ?)"
					+ " where User_Num = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, User_Num);
			pstmt.setInt(2, User_Num);
			cnt = pstmt.executeUpdate();
			
		} finally {
			if (pstmt!=null) pstmt.close();
			if (conn!=null) conn.close();
		}
		return cnt;
		
	}	// end inputPoint
	
	
	
	public int inputPoint(SellDTO dto) throws SQLException {
		int User_Num = dto.getUser_Num();
		int cnt = this.inputPoint(User_Num);
		return cnt;
	}
	public int changeVolume(int Sell_Volume, int Item_Num) throws SQLException{
		int cnt = 0;
		
		try {
			String sql = "update stock set Item_Volume = (Item_Volume - ?) where item_Num = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Sell_Volume);
			pstmt.setInt(2, Item_Num);
			cnt = pstmt.executeUpdate();
		} finally {
			if(pstmt!=null) pstmt.close();
			if(conn!=null) conn.close();
		}
		return cnt;
	} // end changeVolume()
	
	public int changeVolume(SellDTO dto) throws SQLException{
		int Sell_Volume = dto.getSell_Volume();
		int Item_Num = dto.getItem_Num();
		int cnt = this.changeVolume(Sell_Volume, Item_Num);
		return cnt;
		
	} // end changeVolume(dto)
	
	
	
	public SellDTO[] createArray(ResultSet rs) throws SQLException {
		ArrayList<SellDTO> list = new ArrayList<SellDTO>();
		
		while(rs.next()) {
			int Sell_Num = rs.getInt(1);
			int Item_Num = rs.getInt(2);
			String Item_Name = rs.getString(3);
			int Sell_Price = rs.getInt(4);
			int Item_Volume = rs.getInt(5);
			Date Sell_Date = rs.getDate(6); 
			int User_Num = rs.getInt(7);
			int Sell_Volume = rs.getInt(8);
			String Sell_Place = rs.getString(9);
			
			SellDTO dto = new SellDTO(Item_Num, Sell_Volume, Sell_Place, User_Num);
			dto.setSell_Num(Sell_Num);
			dto.setSell_Date(Sell_Date);
			dto.setSell_Price(Sell_Price);
			dto.setItem_Volume(Item_Volume);
			dto.setItem_Name(Item_Name);
			
			list.add(dto);
		}	// end while
		
		SellDTO[] arr = new SellDTO[list.size()];
		list.toArray(arr);
		return arr;
	}	// end createArray() 값들이 저장된 배열 만들기
	
	// 일단 입력받은것만 출력되는 셀렉트 구문
	public SellDTO[] select() throws SQLException {
		 
		try {
		String sql = "Select "
					+ "s2.Sell_Num 판매번호, s1.Item_Num 재품번호, "
					+ "s1.Item_Name 제품명, s1.Sell_Price 판매가격, s1.Item_Volume 재품수량, "
					+ "s2.Sell_Date 판매일자, s2.User_Num 고객넘버, s2.Sell_Volume 판매수량, s2.Sell_Place 판매장소 "
					+ "From stock s1 "
					+ "Inner Join sell s2 "
					+ "on s1.item_num = s2.item_num "
					+ "order by s2.Sell_Num desc";
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		return createArray(rs);
		
		} finally {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		}
	} //end select();
	
	
	
	//TODO DELETE -- 구매내역 삭제/취소
	public int deleteById(String Sell_Num) throws SQLException {
		
		String sql = "DELETE FROM SELL WHERE Sell_Num = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, Sell_Num);
			int cnt = pstmt.executeUpdate();
			return cnt;
		} finally {
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		}
		
	}	// end DeleteById()
	
	//TODO MODIFY -- 판매정보 수정
	public int modifyById(int Item_Num, int Sell_Volume, String Sell_Place, int User_Num, int Sell_Num) throws SQLException {
		int cnt = 0;
		String sql = "UPDATE SELL SET Item_Num = ? , Sell_Date = sysdate, "
				+ "Sell_Volume = ?, Sell_Place = ?, User_Num = ? WHERE Sell_Num = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Item_Num);
			pstmt.setInt(2, Sell_Volume);
			pstmt.setString(3, Sell_Place);
			pstmt.setInt(4, User_Num);
			pstmt.setInt(5, Sell_Num);
			cnt = pstmt.executeUpdate();	// 성공 1, 실패 0
			return cnt;
		} finally {
			if(rs !=null) rs.close();	// 필요함???
			if(pstmt!=null) pstmt.close();
			if(conn !=null) conn.close();
		}
	}	// end ModifyById()
	
	public int modifyById(SellDTO dto) throws SQLException {
		int Item_Num = dto.getItem_Num();
		int Sell_Volume = dto.getSell_Volume();
		String Sell_Place = dto.getSell_Place();
		int User_Num = dto.getUser_Num();
		int Sell_Num = dto.getSell_Num();
		
		int cnt = this.modifyById(Item_Num, Sell_Volume, Sell_Place, User_Num, Sell_Num);
		return cnt;
		
	}
	
	
}	// end SellDAO()

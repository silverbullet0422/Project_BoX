package sell;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Sell_command {
	void execute(HttpServletRequest request, HttpServletResponse response);

}

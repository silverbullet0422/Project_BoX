
/* Drop Tables */

DROP TABLE BUY CASCADE CONSTRAINTS;
DROP TABLE CUSTOMER CASCADE CONSTRAINTS;
DROP TABLE EMP CASCADE CONSTRAINTS;
DROP TABLE EMPBOARD CASCADE CONSTRAINTS;
DROP TABLE EMPLEVEL CASCADE CONSTRAINTS;
DROP TABLE EVENT CASCADE CONSTRAINTS;
DROP TABLE FnQBOARD CASCADE CONSTRAINTS;
DROP TABLE SELL CASCADE CONSTRAINTS;
DROP TABLE STOCK CASCADE CONSTRAINTS;
DROP TABLE USERBOARD CASCADE CONSTRAINTS;
DROP TABLE USERLEVEL CASCADE CONSTRAINTS;
DROP TABLE WORKTIME CASCADE CONSTRAINTS;




/* Create Tables */

CREATE TABLE BUY
(
	Buy_Num number NOT NULL,
	Item_Num number NOT NULL,
	Buy_Date date NOT NULL,
	Buy_Price number NOT NULL,
	Emp_Num number NOT NULL,
	Buy_Place varchar2(40) NOT NULL,
	Buy_Volume number NOT NULL,
	PRIMARY KEY (Buy_Num)
);


SELECT User_Name FROM CUSTOMER;

CREATE TABLE CUSTOMER
(
	User_Num number NOT NULL,
	User_Name varchar2(20) NOT NULL UNIQUE,
	User_Id varchar2(20) NOT NULL UNIQUE,
	User_Pw varchar2(20) NOT NULL,
	User_Address varchar2(100),
	User_Phonenum varchar2(20) NOT NULL,
	User_Email varchar2(40),
	Point number,
	PRIMARY KEY (User_Num)
);


CREATE TABLE EMP
(
	Emp_Num number NOT NULL,
	Emp_Name varchar2(20) NOT NULL UNIQUE,
	EMP_Id varchar2(20) NOT NULL UNIQUE,
	EMP_Pw varchar2(20) NOT NULL,
	EMP_Address varchar2(100) NOT NULL,
	EMP_Phonenum varchar2(20) NOT NULL,
	EMP_Email varchar2(40) NOT NULL,
	EMP_Position varchar2(20),
	EMP_Start date,
	EMP_Finish date,
	Dept varchar2(20) NOT NULL,
	Pay number NOT NULL,
	Memo clob,
	PRIMARY KEY (Emp_Num)
);


CREATE TABLE EMPBOARD
(
    NUM NUMBER NOT NULL ENABLE, 
	EMP_Id VARCHAR2(20 BYTE) NOT NULL ENABLE,  
	TITLE VARCHAR2(100 BYTE) NOT NULL ENABLE, 
	EMP_CONTENTS CLOB NOT NULL ENABLE, 
	REG_DATE DATE NOT NULL ENABLE, 
	HIT NUMBER, 
	RE_REF NUMBER, 
	RE_LEV NUMBER, 
	RE_SEQ NUMBER, 
    PRIMARY KEY ("NUM")
);

select * from emp;

select * from empboard;
create sequence empboard_seq;

CREATE TABLE EMPLEVEL
(
	Position_Level number NOT NULL,
	Position_Name varchar2(20) NOT NULL UNIQUE,
	PRIMARY KEY (Position_Level)
);


CREATE TABLE EVENT
(
	Ev_Num number NOT NULL,
	Ev_Name varchar2(100) NOT NULL,
	Regdate date NOT NULL,
	PRIMARY KEY (Ev_Num)
);


CREATE TABLE FnQBOARD
(
	Boardnum number NOT NULL,
	Name varchar2(20) NOT NULL,
	Title varchar2(100) NOT NULL,
	FnQ_contents varchar2(1000) NOT NULL,
	Regdate date NOT NULL,
	PRIMARY KEY (Boardnum)
);


CREATE TABLE SELL
(
	Sell_Num number NOT NULL,
	Item_Num number NOT NULL,
	Sell_Date date NOT NULL,
	Sell_Price number NOT NULL,
	Sell_Volume number NOT NULL,
	Sell_Place varchar2(40) NOT NULL,
	User_Num number NOT NULL,
	PRIMARY KEY (Sell_Num)
);


CREATE TABLE STOCK
(
	Item_Num number NOT NULL,
	Item_Name varchar2(100) NOT NULL,
	Item_Class varchar2(20) NOT NULL,
	Item_Volume number NOT NULL,
	Item_img varchar2(100) NOT NULL,
	Buy_Price number NOT NULL,
	Sell_Price number NOT NULL,
	PRIMARY KEY (Item_Num)
);


CREATE TABLE USERBOARD
(
	 NUM NUMBER NOT NULL ENABLE, 
	USER_Id VARCHAR2(20 BYTE) NOT NULL ENABLE,  
	TITLE VARCHAR2(100 BYTE) NOT NULL ENABLE, 
	USER_CONTENTS CLOB NOT NULL ENABLE, 
	REG_DATE DATE NOT NULL ENABLE, 
	HIT NUMBER, 
	RE_REF NUMBER, 
	RE_LEV NUMBER, 
	RE_SEQ NUMBER, 
    PRIMARY KEY ("NUM")
);


CREATE TABLE USERLEVEL
(
	Point_Level number NOT NULL,
	Point_Start number NOT NULL,
	Point_End number NOT NULL,
	Point_Percent number NOT NULL,
	Level_Name varchar2(20) NOT NULL,
	Reward varchar2(1000) NOT NULL,
	PRIMARY KEY (Point_Level)
);


CREATE TABLE WORKTIME
(
	Emp_Num number NOT NULL,
	Start_Time date,
	Finish_Time date,
	PRIMARY KEY (Emp_Num)
);



